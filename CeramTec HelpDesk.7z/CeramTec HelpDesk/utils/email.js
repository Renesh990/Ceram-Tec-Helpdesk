const nodemailer = require('nodemailer');

async function sendEmail(to, subject, text) {
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS, // Use Gmail App Password
        },
    });

    // Only send to IT or IT Helpdesk
    if (["it@ceramtec.com", "it_helpdesk@ceramtec.com.my"].includes(to)) {
        await transporter.sendMail({
            from: `"CeramTec HelpDesk" <${process.env.EMAIL_USER}>`,
            to,
            subject,
            text,
        });
        console.log(`Email sent to: ${to}`);
    } else {
        console.log(`Email blocked: ${to} is not an IT address`);
    }
}

module.exports = sendEmail;
