const express = require('express');
const router = express.Router();
const Ticket = require('../models/Tickets');

// Middleware: Only IT & IT Helpdesk can edit
function requireIT(req, res, next) {
    if (req.user && (req.user.role === 'IT' || req.user.role === 'IT_HELPDESK')) {
        return next();
    }
    return res.status(403).json({ message: 'Only IT or IT Helpdesk can edit tickets.' });
}

// Create new ticket
router.post('/submit', async (req, res) => {
    try {
        let { title, description, hardware, software, department } = req.body;

        // Departments sorted alphabetically
        const departments = ["Account", "Planning", "Sales"].sort();
        if (!departments.includes(department)) {
            return res.status(400).json({ message: "Invalid department selected." });
        }

        // Save ticket with new fields
        const newTicket = await Ticket.create({
            title,
            description,
            hardware,
            software,
            department
        });

        res.json({ message: "Ticket submitted successfully!", ticket: newTicket });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Edit ticket (Only IT or IT Helpdesk)
router.put('/edit/:id', requireIT, async (req, res) => {
    try {
        const ticket = await Ticket.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(ticket);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
