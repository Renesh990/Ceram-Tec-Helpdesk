const mongoose = require('mongoose');

const TicketSchema = new mongoose.Schema({
    ticketNumber: { 
        type: String, 
        unique: true,
        index: true 
    },
    name: { 
        type: String, 
        required: [true, 'Name is required'],
        trim: true
    },
    employeeId: { 
        type: String, 
        required: [true, 'Employee ID is required'],
        trim: true
    },
    department: { 
        type: String, 
        required: [true, 'Department is required'],
        enum: ['IT', 'HR', 'Admin', 'Engineering', 'QA/QC', 'Safety', 'Other']
    },
    issueType: { 
        type: String, 
        required: true,
        enum: ['Hardware', 'Software'] 
    },
    hardwareType: {
        type: String,
        enum: ['Desktop', 'Laptop', 'Printer', 'Panel', 'TV', 'Other'],
        required: function() { return this.issueType === 'Hardware'; }
    },
    softwareType: {
        type: String,
        enum: ['Windows', 'Microsoft Office', 'OMS', 'Other'],
        required: function() { return this.issueType === 'Software'; }
    },
    description: { 
        type: String, 
        required: [true, 'Description is required'],
        minlength: 10
    },
    status: { 
        type: String, 
        default: 'Unassigned',
        enum: ['Unassigned', 'In Progress', 'Completed', 'Cancelled']
    },
    priority: {
        type: String,
        enum: ['Low', 'Medium', 'High', 'Urgent'],
        default: 'Medium'
    },
    assignedTo: {
        type: String,
        default: 'Unassigned'
    },
    createdAt: { 
        type: Date, 
        default: Date.now 
    },
    completedAt: { 
        type: Date 
    }
});

// Add index for better performance
TicketSchema.index({ status: 1, department: 1, priority: 1 });

module.exports = mongoose.model('Ticket', TicketSchema);