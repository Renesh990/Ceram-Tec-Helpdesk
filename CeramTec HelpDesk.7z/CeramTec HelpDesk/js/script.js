document.addEventListener('DOMContentLoaded', function() {
    // Current user (for demo purposes)
    const currentUser = "admin@ceramtec.com";
    let currentView = '';
    let tickets = [];

    // DOM Elements
    const sidebarButtons = {
        unassigned: document.getElementById('unassignedBtn'),
        teamsTickets: document.getElementById('teamsTicketsBtn'),
        teamsClosed: document.getElementById('teamsClosedBtn'),
        ticketMailbox: document.getElementById('ticketMailboxBtn'),
        myTickets: document.getElementById('myTicketsBtn'),
        myRequests: document.getElementById('myRequestsBtn'),
        myClosed: document.getElementById('myClosedBtn')
    };

    const form = document.getElementById('ticketForm');
    const ticketsTable = document.querySelector('.tickets-table-card');
    const tableBody = document.getElementById('ticketsTableBody');
    const tableTitle = document.getElementById('tableTitle');
    const ticketModal = new bootstrap.Modal(document.getElementById('ticketModal'));
    const ticketDetails = document.getElementById('ticketDetails');
    const assignToMeBtn = document.getElementById('assignToMeBtn');
    const completeTicketBtn = document.getElementById('completeTicketBtn');
    let currentTicketId = null;

    // Initialize the application
    init();

    function init() {
        // Load tickets from server
        loadTickets();
        
        // Setup event listeners
        setupEventListeners();
    }

    function setupEventListeners() {
        // Toggle hardware/software fields
        document.querySelectorAll('input[name="issueType"]').forEach(radio => {
            radio.addEventListener('change', function() {
                if (this.value === 'Hardware') {
                    document.getElementById('hardwareFields').style.display = 'block';
                    document.getElementById('softwareFields').style.display = 'none';
                    document.getElementById('hardwareType').required = true;
                    document.getElementById('softwareType').required = false;
                } else {
                    document.getElementById('hardwareFields').style.display = 'none';
                    document.getElementById('softwareFields').style.display = 'block';
                    document.getElementById('hardwareType').required = false;
                    document.getElementById('softwareType').required = true;
                }
            });
        });

        // Form submission
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            await createTicket();
        });

        // Cancel button
        document.getElementById('cancelBtn').addEventListener('click', function() {
            if (confirm('Are you sure you want to cancel this ticket?')) {
                form.reset();
                document.getElementById('hardwareFields').style.display = 'block';
                document.getElementById('softwareFields').style.display = 'none';
            }
        });

        // Sidebar buttons
        Object.keys(sidebarButtons).forEach(key => {
            sidebarButtons[key].addEventListener('click', function() {
                setActiveView(key);
                showTicketsTable();
                updateTableTitle();
                filterTickets();
            });
        });

        // Modal buttons
        assignToMeBtn.addEventListener('click', async function() {
            await assignTicketToMe();
        });

        completeTicketBtn.addEventListener('click', async function() {
            await completeTicket();
        });
    }

    async function loadTickets() {
        try {
            const response = await fetch('/api/tickets');
            if (response.ok) {
                tickets = await response.json();
                updateSidebarCounts();
            } else {
                throw new Error('Failed to load tickets');
            }
        } catch (error) {
            console.error('Error loading tickets:', error);
            alert('Error loading tickets. Please try again.');
        }
    }

    function updateSidebarCounts() {
        // Unassigned tickets
        const unassignedCount = tickets.filter(t => t.status === 'Unassigned').length;
        sidebarButtons.unassigned.querySelector('.badge').textContent = unassignedCount;

        // Teams Tickets (all active tickets except current user's)
        const teamsTicketsCount = tickets.filter(t => 
            t.status !== 'Completed' && t.status !== 'Cancelled' && 
            t.assignedTo !== currentUser && t.assignedTo !== 'Unassigned'
        ).length;
        sidebarButtons.teamsTickets.querySelector('.badge').textContent = teamsTicketsCount;

        // Teams Closed (all completed tickets)
        const teamsClosedCount = tickets.filter(t => 
            t.status === 'Completed' || t.status === 'Cancelled'
        ).length;
        sidebarButtons.teamsClosed.querySelector('.badge').textContent = teamsClosedCount;

        // Ticket Mailbox (all unassigned tickets)
        const ticketMailboxCount = unassignedCount;
        sidebarButtons.ticketMailbox.querySelector('.badge').textContent = ticketMailboxCount;

        // My Tickets (tickets assigned to current user)
        const myTicketsCount = tickets.filter(t => 
            t.assignedTo === currentUser && t.status !== 'Completed' && t.status !== 'Cancelled'
        ).length;
        sidebarButtons.myTickets.querySelector('.badge').textContent = myTicketsCount;

        // My Requests (tickets created by current user)
        const myRequestsCount = tickets.filter(t => 
            t.requestedBy === currentUser && t.status !== 'Completed' && t.status !== 'Cancelled'
        ).length;
        sidebarButtons.myRequests.querySelector('.badge').textContent = myRequestsCount;

        // My Closed (completed tickets created by current user)
        const myClosedCount = tickets.filter(t => 
            t.requestedBy === currentUser && (t.status === 'Completed' || t.status === 'Cancelled')
        ).length;
        sidebarButtons.myClosed.querySelector('.badge').textContent = myClosedCount;
    }

    function setActiveView(view) {
        currentView = view;
        // Remove active class from all buttons
        Object.values(sidebarButtons).forEach(btn => {
            btn.classList.remove('active');
        });
        // Add active class to clicked button
        sidebarButtons[view].classList.add('active');
    }

    function showTicketsTable() {
        ticketsTable.style.display = 'block';
    }

    function updateTableTitle() {
        const titles = {
            unassigned: 'Unassigned Tickets',
            teamsTickets: 'Team Tickets',
            teamsClosed: 'Closed Tickets',
            ticketMailbox: 'Ticket Mailbox',
            myTickets: 'My Assigned Tickets',
            myRequests: 'My Requested Tickets',
            myClosed: 'My Closed Tickets'
        };
        tableTitle.textContent = titles[currentView];
    }

    function filterTickets() {
        let filteredTickets = [];
        
        switch(currentView) {
            case 'unassigned':
                filteredTickets = tickets.filter(t => t.status === 'Unassigned');
                break;
            case 'teamsTickets':
                filteredTickets = tickets.filter(t => 
                    t.status !== 'Completed' && t.status !== 'Cancelled' && 
                    t.assignedTo !== currentUser && t.assignedTo !== 'Unassigned'
                );
                break;
            case 'teamsClosed':
                filteredTickets = tickets.filter(t => 
                    t.status === 'Completed' || t.status === 'Cancelled'
                );
                break;
            case 'ticketMailbox':
                filteredTickets = tickets.filter(t => t.status === 'Unassigned');
                break;
            case 'myTickets':
                filteredTickets = tickets.filter(t => 
                    t.assignedTo === currentUser && t.status !== 'Completed' && t.status !== 'Cancelled'
                );
                break;
            case 'myRequests':
                filteredTickets = tickets.filter(t => 
                    t.requestedBy === currentUser && t.status !== 'Completed' && t.status !== 'Cancelled'
                );
                break;
            case 'myClosed':
                filteredTickets = tickets.filter(t => 
                    t.requestedBy === currentUser && (t.status === 'Completed' || t.status === 'Cancelled')
                );
                break;
        }

        renderTicketsTable(filteredTickets);
    }

    function renderTicketsTable(tickets) {
        tableBody.innerHTML = '';
        
        if (tickets.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="9" class="text-center">No tickets found</td></tr>';
            return;
        }

        tickets.forEach(ticket => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${ticket.ticketNumber}</td>
                <td>${ticket.description.substring(0, 30)}${ticket.description.length > 30 ? '...' : ''}</td>
                <td><span class="badge ${getStatusBadgeClass(ticket.status)}">${ticket.status}</span></td>
                <td><span class="badge ${getPriorityBadgeClass(ticket.priority)}">${ticket.priority}</span></td>
                <td>${ticket.issueType === 'Hardware' ? ticket.hardwareType : ticket.softwareType}</td>
                <td>${ticket.name}</td>
                <td>${ticket.assignedTo}</td>
                <td>${new Date(ticket.createdAt).toLocaleDateString()}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary view-btn" data-id="${ticket._id}">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });

        // Add event listeners to view buttons
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const ticketId = this.getAttribute('data-id');
                showTicketDetails(ticketId);
            });
        });
    }

    function getStatusBadgeClass(status) {
        switch(status) {
            case 'Unassigned': return 'bg-secondary';
            case 'In Progress': return 'bg-primary';
            case 'Completed': return 'bg-success';
            case 'Cancelled': return 'bg-danger';
            default: return 'bg-secondary';
        }
    }

    function getPriorityBadgeClass(priority) {
        switch(priority) {
            case 'Low': return 'bg-success';
            case 'Medium': return 'bg-warning text-dark';
            case 'High': return 'bg-danger';
            case 'Urgent': return 'bg-danger';
            default: return 'bg-secondary';
        }
    }

    async function showTicketDetails(ticketId) {
        currentTicketId = ticketId;
        const ticket = tickets.find(t => t._id === ticketId);
        
        if (!ticket) {
            alert('Ticket not found');
            return;
        }

        ticketDetails.innerHTML = `
            <div class="row mb-3">
                <div class="col-md-6">
                    <h5>Ticket #${ticket.ticketNumber}</h5>
                    <p><strong>Status:</strong> <span class="badge ${getStatusBadgeClass(ticket.status)}">${ticket.status}</span></p>
                    <p><strong>Priority:</strong> <span class="badge ${getPriorityBadgeClass(ticket.priority)}">${ticket.priority}</span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Created:</strong> ${new Date(ticket.createdAt).toLocaleString()}</p>
                    ${ticket.completedAt ? `<p><strong>Completed:</strong> ${new Date(ticket.completedAt).toLocaleString()}</p>` : ''}
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <p><strong>Requested By:</strong> ${ticket.name} (${ticket.employeeId})</p>
                    <p><strong>Department:</strong> ${ticket.department}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>Assigned To:</strong> ${ticket.assignedTo}</p>
                    <p><strong>Issue Type:</strong> ${ticket.issueType}</p>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-12">
                    <p><strong>${ticket.issueType} Type:</strong> ${ticket.issueType === 'Hardware' ? ticket.hardwareType : ticket.softwareType}</p>
                </div>
            </div>
            
            <div class="row">
                <div class="col-12">
                    <h5>Description</h5>
                    <div class="ticket-description">
                        ${ticket.description}
                    </div>
                </div>
            </div>
        `;

        // Show/hide action buttons based on ticket status
        assignToMeBtn.style.display = ticket.status === 'Unassigned' ? 'block' : 'none';
        completeTicketBtn.style.display = ticket.assignedTo === currentUser && ticket.status === 'In Progress' ? 'block' : 'none';

        ticketModal.show();
    }

    async function createTicket() {
        const formData = {
            name: document.getElementById('name').value,
            employeeId: document.getElementById('employeeId').value,
            department: document.getElementById('department').value,
            priority: document.querySelector('input[name="priority"]:checked').value,
            issueType: document.querySelector('input[name="issueType"]:checked').value,
            description: document.getElementById('description').value,
            requestedBy: currentUser
        };

        // Add hardware/software type
        if (formData.issueType === 'Hardware') {
            formData.hardwareType = document.getElementById('hardwareType').value;
        } else {
            formData.softwareType = document.getElementById('softwareType').value;
        }

        try {
            const response = await fetch('/api/tickets', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });
            
            if (response.ok) {
                const newTicket = await response.json();
                tickets.push(newTicket);
                updateSidebarCounts();
                
                alert(`Ticket #${newTicket.ticketNumber} created successfully!`);
                form.reset();
                
                // Reset to hardware view
                document.getElementById('hardwareFields').style.display = 'block';
                document.getElementById('softwareFields').style.display = 'none';
                
                // If on unassigned view, refresh the table
                if (currentView === 'unassigned' || currentView === 'ticketMailbox') {
                    filterTickets();
                }
            } else {
                throw new Error('Failed to create ticket');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error creating ticket. Please try again.');
        }
    }

    async function assignTicketToMe() {
        try {
            const response = await fetch(`/api/tickets/${currentTicketId}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    assignedTo: currentUser,
                    status: 'In Progress'
                })
            });
            
            if (response.ok) {
                const updatedTicket = await response.json();
                
                // Update local tickets array
                const index = tickets.findIndex(t => t._id === currentTicketId);
                if (index !== -1) {
                    tickets[index] = updatedTicket;
                }
                
                updateSidebarCounts();
                ticketModal.hide();
                
                // Refresh the current view
                filterTickets();
            } else {
                throw new Error('Failed to assign ticket');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error assigning ticket. Please try again.');
        }
    }

    async function completeTicket() {
        try {
            const response = await fetch(`/api/tickets/${currentTicketId}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    status: 'Completed',
                    completedAt: new Date()
                })
            });
            
            if (response.ok) {
                const updatedTicket = await response.json();
                
                // Update local tickets array
                const index = tickets.findIndex(t => t._id === currentTicketId);
                if (index !== -1) {
                    tickets[index] = updatedTicket;
                }
                
                updateSidebarCounts();
                ticketModal.hide();
                
                // Refresh the current view
                filterTickets();
            } else {
                throw new Error('Failed to complete ticket');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error completing ticket. Please try again.');
        }
    }
});